SELECT count(*) AS value FROM store_sales;
